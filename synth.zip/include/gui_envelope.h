#ifndef GUI_ENVELOPE_H
#define GUI_ENVELOPE_H
#include "gui_interface.h"
#include "raylib.h"

void DrawEnvelopePage(AppState *state, int zoneX);

#endif

#ifndef GUI_OUTPUT_H
#define GUI_OUTPUT_H
#include "gui_interface.h"

void DrawOutputPage(AppState *state, int zoneX);
#endif

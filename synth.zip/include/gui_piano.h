#ifndef GUI_PIANO_H
#define GUI_PIANO_H

#include "gui_interface.h"

void DrawPianoPage(AppState *state, int zoneX);

#endif

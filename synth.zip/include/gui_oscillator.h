#ifndef GUI_OSCILLATOR_H
#define GUI_OSCILLATOR_H

#include "gui_interface.h"

void DrawOscillatorPage(AppState *state, int zoneX);

#endif

#ifndef DSP_CONFIG_H
#define DSP_CONFIG_H

#define SAMPLE_RATE 44100.0f
#define VIS_BUFFER_SIZE 1024 // for signal representation, not audio output

#endif

#ifndef DSP_UTILS_H
#define DSP_UTILS_H

float midi_to_freq(int midiNote);
float soft_clip(float x);

#endif

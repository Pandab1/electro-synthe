#ifndef INPUT_H
#define INPUT_H

#include "gui_interface.h"

void HandleKeyboardShortcuts(AppState *s);

#endif

#include "custom_math.h"
#include "gui_interface.h"
#include "input.h"
#include "raylib.h"
#include "utils_files.h"
#include "utils_maths.h"
#include "miniaudio.h"
#include "dsp_voice.h"
#include "dsp_api.h"
#include "dsp_adsr.h"

#include <stdio.h>

#define FREQ 44100

struct Notes {
  float freq;
  float dur;
};

enum WaveType { SIN, SQU, ST, TRI };

void generate_sound(FILE *f, u32 num_sample, u32 num_notes,
                    struct Notes notes[], enum WaveType type);

//MINIAUDIO CALLBACK
void data_callback(ma_device *device, void *output, const void *input,
                   ma_uint32 frameCount) {
  float *out = (float *)output;
  for (ma_uint32 i = 0; i < frameCount; i++)
    out[i] = synth_next_sample();
}

int main(void) {
  //DSP INIT
  voice_init();
  //MINIAUDIO INIT
  ma_device_config config = ma_device_config_init(ma_device_type_playback);
  config.playback.format = ma_format_f32;
  config.playback.channels = 1;
  config.sampleRate = SAMPLE_RATE;
  config.dataCallback = data_callback;
  // MINIAUDIO DEVICE
  ma_device device;
  if (ma_device_init(NULL, &config, &device) != MA_SUCCESS)
    return -1;
  if (ma_device_start(&device) != MA_SUCCESS)
    return -1;

  const int screenWidth = 1000;
  const int screenHeight = 800;

  SetConfigFlags(FLAG_WINDOW_RESIZABLE);
  InitWindow(screenWidth, screenHeight, "Electro-synthé");
  SetWindowMinSize(780, 600);
  SetTargetFPS(60);

  // Init state
  AppState myState = {.showMessage = false,
                      .darkMode = false,
                      .sliderValue = 50.0f,
                      .playbackMode = MODE_CONTINUOUS,
                      .adsr = env, // set default ADSR
                    };

  InitGuiStyle();

  while (!WindowShouldClose()) {
    AudioManager(&myState, &env);
    HandleKeyboardShortcuts(&myState);

    BeginDrawing();
    // gui.c
    DrawAppInterface(&myState);
    EndDrawing();
  }
  CloseWindow();
  return 0;

  FILE *f_sin = fopen("sin.wav", "wb");
  FILE *f_squ = fopen("squ.wav", "wb");
  FILE *f_st = fopen("st.wav", "wb");
  FILE *f_tri = fopen("tri.wav", "wb");

  struct Notes notes[] = {
      {392, 60.0f / 76}, {440, 60.0f / 76}, {294, 60.0f / 114},
      {440, 60.0f / 76}, {494, 60.0f / 76},
  };

  u32 num_notes = sizeof(notes) / sizeof(notes[0]);

  float duration = 0.0f;
  for (u32 i = 0; i < num_notes; i++) {
    duration += notes[i].dur;
  }

  u32 num_sample = (u32)(duration * FREQ);
  u32 file_size = num_sample * sizeof(u16) + 44;

  create_file_header(f_sin, file_size, FREQ, num_sample);
  create_file_header(f_squ, file_size, FREQ, num_sample);
  create_file_header(f_st, file_size, FREQ, num_sample);
  create_file_header(f_tri, file_size, FREQ, num_sample);

  generate_sound(f_sin, num_sample, num_notes, notes, SIN);
  generate_sound(f_squ, num_sample, num_notes, notes, SQU);
  generate_sound(f_st, num_sample, num_notes, notes, ST);
  generate_sound(f_tri, num_sample, num_notes, notes, TRI);

  fclose(f_sin);
  fclose(f_squ);
  fclose(f_st);
  fclose(f_tri);

  return 0;
}

void generate_sound(FILE *f, u32 num_sample, u32 num_notes,
                    struct Notes notes[], enum WaveType type) {
  u32 cur_note = 0;
  float cur_note_start = 0.0f;
  for (u32 i = 0; i < num_sample; i++) {
    float t = (float)i / FREQ;

    float y = 0.0f;

    if (cur_note < num_notes) {
      switch (type) {
      case SIN:
        y = generate_sin(t, notes[cur_note].freq);
        break;
      case SQU:
        y = generate_square(t, notes[cur_note].freq);
        break;
      case ST:
        y = generate_sawtooth(t, notes[cur_note].freq);
        break;
      case TRI:
        y = generate_triangle(t, notes[cur_note].freq);
        break;
      }

      if (t > cur_note_start + notes[cur_note].dur) {
        cur_note++;
        cur_note_start = t;
      }
    }
    i16 sample = (i16)(y * INT16_MAX);

    write_le_16(f, sample);
  }
}

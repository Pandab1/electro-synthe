#ifndef GUI_HELP_H
#define GUI_HELP_H
#include "gui_interface.h"
#include "raylib.h"

void DrawHelpPage(AppState *state, int zoneX);
#endif

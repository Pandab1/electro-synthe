#ifndef DSP_API_H
#define DSP_API_H

#include "gui_interface.h"

void AudioManager(AppState *state, ADSR *env);

#endif